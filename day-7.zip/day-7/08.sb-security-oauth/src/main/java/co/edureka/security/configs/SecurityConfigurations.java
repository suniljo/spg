package co.edureka.security.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfigurations {

	@Bean
	public SecurityFilterChain customSecurityConfigurations(HttpSecurity http) throws Exception{
		return http.authorizeHttpRequests(request -> request.anyRequest()
													 .authenticated())
			.csrf(csrf -> csrf.disable())
			.oauth2Login(Customizer.withDefaults()) //configures authentication support using OAuth2.0
			.build();		
	}
}
