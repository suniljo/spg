package co.edureka.security.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeRestController {

	@GetMapping(path = "/welcome")
	public String showWelcomeMessage() {
		return "Welcome to edureka!!!";
	}
}
