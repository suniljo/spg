package co.edureks.security.controllers;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import co.edureks.security.models.Product;

@RestController
public class ProductRestController {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	List<Product> productsList = new ArrayList<>();
	Product prod1 = new Product(101, "Mobile");
	Product prod2 = new Product(102, "Computer");
	Product prod3 = new Product(103, "Laptop");
	
	
	public ProductRestController() {
		productsList.add(prod1);
		productsList.add(prod2);
		productsList.add(prod3);		
	}

	@GetMapping("/products") 
	public List<Product> getAllProducts() {
		return productsList;
	}

	@GetMapping("/products/{pid}")
	public Product getProductByProductId(@PathVariable Integer pid) {
		Product product = productsList.stream()
									  .filter(prod -> prod.productId().equals(pid)).findFirst().orElse(null);
		return product;
	}

	@PostMapping("/products")
	public void addNewProduct(@RequestBody Product product) {
		productsList.add(product);
		logger.info("saving new product {}", product);
	}
	
	
}
