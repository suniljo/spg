package co.edureks.security.models;

public record Product(Integer productId, String productName) {}
