package co.edureka.security.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfigurations {
	
	@Bean
	public SecurityFilterChain customSecurityConfigs(HttpSecurity http) throws Exception {
		System.out.println("inside SecurityFilterChain");
		http.authorizeHttpRequests(request -> request.anyRequest().authenticated());
		
		http.csrf(csrf -> csrf.disable());
		
		http.httpBasic(Customizer.withDefaults());
		
		SecurityFilterChain filterChain = http.build();
		
		return filterChain;
	}
	
	//UserDetailsService ---> core interface which loads user-specific data- provides the ability to create new users and update existing ones.
	@Bean
	public UserDetailsService manageUsers() {
		System.out.println("inside UserDetailsService");
		UserDetails user1 = User.withUsername("admin")
							    .password("{noop}12345")
							    .roles("ADMIN")
							    .build();
		
		var user2 = User.withUsername("sanjay")
			    				.password("{noop}12345")
			    				.roles("MANAGER")
			    				.build();
		
		/*
		UserDetailsManager userDtlsMgr = new InMemoryUserDetailsManager();		
		userDtlsMgr.createUser(user1);
		userDtlsMgr.createUser(user2);
		*/

		UserDetailsManager userDtlsMgr = new InMemoryUserDetailsManager(user1, user2);		
		return userDtlsMgr;
	}
}
