package co.edureka.boot.security.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import co.edureka.boot.security.services.CustomUserDetailsService;

@Configuration
@EnableWebSecurity
public class SecurityConfigurations {

    private final CustomUserDetailsService userDetailsService;

    public SecurityConfigurations(CustomUserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider(UserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {        
    	//DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        //provider.setUserDetailsService(userDetailsService);
    	DaoAuthenticationProvider provider = new DaoAuthenticationProvider(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public SecurityFilterChain customSecurityConfigs(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Disable CSRF for simplicity in this example
            .authorizeHttpRequests(auth -> auth
            								.requestMatchers("/register")
            								.permitAll() // allow registration without authentication
            								.anyRequest()
            								.authenticated() // all other requests require authentication
            );
            /*
            .formLogin(form -> form
                .permitAll()
            )
            .logout(logout -> logout.permitAll());
        	*/
        http.httpBasic(Customizer.withDefaults());
        
        return http.build();
    }
}

/*
.formLogin(form -> form
                .loginPage("/login") // Specify your custom login page URL
                .loginProcessingUrl("/login") // URL to process login form submission (default)
                .defaultSuccessUrl("/home", true) // Redirect after successful login
                .failureUrl("/login?error") // Redirect on login failure
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout") // URL to trigger logout
                .logoutSuccessUrl("/login?logout") // Redirect after successful logout
                .permitAll()
            );
*/
