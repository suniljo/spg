package co.edureka.order.repository;

import org.springframework.data.repository.CrudRepository;

import co.edureka.order.entity.Order;

public interface OrderRepository extends CrudRepository<Order, Long> {

}
